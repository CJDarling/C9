﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listView2.View = View.Details;
            listView2.Columns.Add("Films", 1000);
        }
      

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            listView2.Items.Clear();
            string MovieTitle = textBox1.Text;
            string MovieYear = textBox2.Text;
            System.Net.WebClient webclient = new System.Net.WebClient();
            string webData = webclient.DownloadString("http://www.omdbapi.com/?apikey=29739845&s=" + MovieTitle + "&y=" + MovieYear);
            var items = JsonConvert.DeserializeObject<RootObject>(webData);
            ImageList imgs = new ImageList();
            imgs.ImageSize = new Size(50, 50);
            listView2.SmallImageList = imgs;
            for (int i = 0; i < items.Search.Count(); i++) {
                try
                {
                    WebClient wc = new WebClient();
                    byte[] bytes = wc.DownloadData(items.Search[i].Poster);
                    MemoryStream ms = new MemoryStream(bytes);
                    imgs.Images.Add(Image.FromStream(ms));       
                }
                catch { }
                listView2.Items.Add(items.Search[i].ToString(), i);
                listView2.Items[i].Tag = items.Search[i];

            }
            textBox4.Text = items.ToString();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < listView2.CheckedItems.Count; i++) {
                ListViewItem item = listView2.CheckedItems[i];
                try
                {
                    Search film = (Search)item.Tag;
                    string MovieTitle = film.Title;
                    listView1.Items.Add(MovieTitle);
                }
                catch {
                    Result film = (Result)item.Tag;
                    string MovieTitle = film.title;
                    listView1.Items.Add(MovieTitle);
                }
                
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }


        private void button3_Click_1(object sender, EventArgs e)
        {
            for (int i = listView1.Items.Count - 1; i >= 0; i--)
            {
                if (listView1.Items[i].Checked)
                {
                    listView1.Items[i].Remove();
                }
            }
        }
        

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            listView2.Items.Clear();
            string MovieTitle = textBox1.Text;
            listView2.Text = "";
            System.Net.WebClient webclient = new System.Net.WebClient();
            string webData = webclient.DownloadString("https://api.themoviedb.org/3/search/movie?api_key=0853e59fd43ca7f94bd83ad97d04ebec&query=" + MovieTitle);
            var items2 = JsonConvert.DeserializeObject<RootObject2>(webData);
            ImageList imgs = new ImageList();
            imgs.ImageSize = new Size(50, 50);
            listView2.SmallImageList = imgs;
            for (int i = 0; i < items2.results.Count(); i++)
            {
                 try
                 {
                    WebClient wc = new WebClient();
                    byte[] bytes = wc.DownloadData("https://image.tmdb.org/t/p/w500/"+items2.results[i].poster_path);
                    MemoryStream ms = new MemoryStream(bytes);
                    imgs.Images.Add(Image.FromStream(ms));
                }
                 catch { } 
                listView2.Items.Add(items2.results[i].ToString(), i);
                listView2.Items[i].Tag = items2.results[i];
            }
            textBox4.Text = items2.ToString();
        }

       
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }


        private void listView2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }
    }

}

