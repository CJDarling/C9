﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp3
{
    public class RootObject2
    {
        public int page { get; set; }
        public int total_results { get; set; }
        public int total_pages { get; set; }
        public List<Result> results { get; set; }

        public override string ToString()
        {
     
            return "Page: "+ page+ ", Total results: " + total_results + ", Total pages: " + total_pages+"\n";
        }
    }
}
