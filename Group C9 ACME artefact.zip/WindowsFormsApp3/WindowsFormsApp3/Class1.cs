﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp3
{

    public class RootObject
    {
        public List<Search> Search { get; set; }
        public string totalResults { get; set; }
        public string Response { get; set; }


        public override string ToString()
        {
            return "Total results: "+totalResults+", Response: "+Response+"\n";
        }
    }

}
