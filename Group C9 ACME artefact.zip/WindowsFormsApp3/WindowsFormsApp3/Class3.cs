﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp3
{

    public class Result
    {
        public int vote_count { get; set; }
        public int id { get; set; }
        public bool video { get; set; }
        public double vote_average { get; set; }
        public string title { get; set; }
        public double popularity { get; set; }
        public string poster_path { get; set; }


        public override string ToString()
        {
            return "Vote count: " + vote_count + ", ID: " + id + ", Video: "+ video + ", Vote average: "+ vote_average+ ", Title: "+title+", Popularity: "+ popularity+ "\n";
        }

    }
}
